//
//  Fortune.swift
//  RandomFortune
//
//  Created by Marco on 3/15/22.
//
// Class for Fortune object
// Holds all fortune information

import Foundation

class Fortune{
    var msg = ""
    var color = ""
    var animal = ""
    var animalURL = ""
    var animalImg = ""
    var luckyNum = 0
}
